package SubjectAndTopics;

public class Topic {
	private String topicName;

	
	
	public Topic(String topicName) {
		super();
		this.topicName = topicName;
	}

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	@Override
	public String toString() {
		return "Topic [topicName=" + topicName + "]";
	}
}
