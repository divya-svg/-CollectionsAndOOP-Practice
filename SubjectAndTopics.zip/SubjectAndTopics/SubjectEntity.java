package SubjectAndTopics;


public class SubjectEntity {
	
	private String subjectName;
	private Topic topics;
	
	public SubjectEntity(String subjectName, Topic topics) {
		super();
		this.subjectName = subjectName;
		this.topics = topics;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public Topic getTopics() {
		return topics;
	}
	
	public void setTopics(Topic topics) {
		this.topics = topics;
	}
	@Override
	public String toString() {
		return "SubjectEntity [subjectName=" + subjectName + ", topics=" + topics + "]";
	}
	
}
