package SubjectAndTopics;

public class main {
	
		
	public static void main(String[] args) {
		InputUtil in = new InputUtil();
		Service ser = new Service();
		ser.existingtopic();

		System.out.println("Welcome to subject and topic assesment");
		while(true) {
			System.out.println("1.add sub 2.add topic 3.display subject 4.displaytopics  0.exit");
			int choose =  in.getint("enter the choice : ");
			
			switch(choose) {
			case 1 :
				ser.addsubject();
				break;
			case 2 :
				ser.addtopic();
				break;
			case 3 :
				ser.displaysubject();
				break;
			case 4:
				ser.displaytopics();
				break;
			case 0:
				System.out.println("the system is exiting.....");
				System.exit(0);
				break;
			}
			
		}
	}

}
