package SubjectAndTopics;

import java.util.Scanner;

public class InputUtil {
	Scanner s = new Scanner(System.in);
	
	public String getstr(String msg) {
		System.out.println(msg);
		return s.next();
	}
	public int getint(String msg) {
		System.out.println(msg);
		if(!s.hasNextInt()) {
			System.out.println("invalid input");
			s.next();
		}
		return s.nextInt();
	}

}
