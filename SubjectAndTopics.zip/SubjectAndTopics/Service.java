package SubjectAndTopics;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
public class Service {
	
	InputUtil in = new InputUtil();
    List<String> sublist = new ArrayList<>(Arrays.asList("Math", "English", "Tamil"));


	Map<Object , List<Topic>> topicmap = new HashMap<>();
	
	public void existingtopic() {
		
		topicmap.put("math", new ArrayList<>(Arrays.asList(
				new Topic("Algebra"),
				new Topic("Geometry")	
				)));
		topicmap.put("English", new ArrayList<>(Arrays.asList(
				new Topic("grammer"),
				new Topic("supplymentary")
				)));
		topicmap.put("Tamil",new ArrayList<>(Arrays.asList(
				new Topic("ilakanam"),
				new Topic("thunaipaadam")
				)));
	}
		

	public void displaytopics() {
		
	    for(Entry<Object, List<Topic>> entry : topicmap.entrySet()) {
	    	System.out.println("subject = > " +" "+entry.getKey());
	    	
	    	for(Topic topic : entry.getValue()) {
	    		System.out.println(topic.getTopicName());
	    	}
	    }
		
	}
    
    public void displaysubject() {
	   for(String s : sublist) {
		System.out.println(s);
	}
}
    
    public void addsubject() {
    	String subname = in.getstr("enter the subject name");
    	
    	boolean exist = sublist.stream().anyMatch(s -> s.equalsIgnoreCase(subname));
    	if(exist) {
    		System.out.println("its already existt");
    	}else {
    	sublist.add(subname);
    	System.out.println("New subject addedsublist successfully");
    	}
    }
    
    public void addtopic() {
         String subname = in.getstr("enter the subject name");
    	
    	boolean exist = sublist.stream().anyMatch(s -> s.equalsIgnoreCase(subname));
    	if(exist) {
    		System.out.println("your mentioned  "+subname + "subject is already exit and also have the topic ");
    		while(true) {
    		System.out.println("if you want to add the more topic for "+" "+ subname +" "+"subject press -1 / exit -0 ");
    		int choose = in.getint("Enter the choice : ");
    		switch(choose) {
    		case 1 :	
    			String topicname = in.getstr("Ente the topic");
    				topicmap.computeIfAbsent(subname, k -> new ArrayList<>()).add(new Topic(topicname));
    			break;
    		case 0 :
    			return;
    		}
    		}
    	}
    	else {
    		System.out.println("your given" + subname + "is not there so , u can add a subject after u can add the topics");
    		
    	}
    	
    }
   

}
 

