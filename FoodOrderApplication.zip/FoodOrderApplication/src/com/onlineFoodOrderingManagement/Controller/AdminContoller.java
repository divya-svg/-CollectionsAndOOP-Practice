package com.onlineFoodOrderingManagement.Controller;

import com.onlineFoodOrderingManagement.InputUtil.InputUtil;
import com.onlineFoodOrderingManagement.Service.AdminserviceImplement;

public class AdminContoller {
	
	static AdminserviceImplement adser = new AdminserviceImplement();
    static InputUtil in = new InputUtil();

	public void showAdmindashboard() {
		
        System.out.println("welcome to admin dashboard");
        while(true) {
        System.out.println(" 1. add item 2. remove item 3. view iteam 4. addCategory 5.removeCatagory 0.main");
        int choose = in.getint("enter the choice :");
        
        switch(choose) {
        case  1 :
        	adser.addIteam();
        	break;
        case 2 :
        	adser.removeIteam();
        	break;
        case 3 :
        	adser.viewIteam();
        	break;
        case 4 :
        	adser.addCategory();
        	break;
        case 5 :
        	adser.removeCatagory();
        	break;
        	
        case 0 :
        	return;
        }
        }
	}


}
