package com.onlineFoodOrderingManagement.Controller;

import com.onlineFoodOrderingManagement.DataBase.DataBase;
import com.onlineFoodOrderingManagement.InputUtil.InputUtil;
import com.onlineFoodOrderingManagement.Service.AdminserviceImplement;
import com.onlineFoodOrderingManagement.Service.CustomerService;

public class CustomerController {
	static AdminserviceImplement adser = new AdminserviceImplement();
	static DataBase db = new DataBase();
	static InputUtil in = new InputUtil();
	static CustomerService cusser = new CustomerService();
	
	public void customerpage() {
		System.out.println("here your list order your favotire");
		adser.viewIteam();
		while(true) {
		System.out.println("1.place your order 0.exit");
		int choose = in.getint("enter your choice");
		
		switch(choose) {
		case 1 :
			cusser.orderplaced();
			break;
		case 0 :
			return;
		}
		}
		}
	}
