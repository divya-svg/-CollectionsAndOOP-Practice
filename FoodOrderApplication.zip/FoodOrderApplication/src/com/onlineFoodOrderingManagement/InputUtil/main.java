package com.onlineFoodOrderingManagement.InputUtil;

import com.onlineFoodOrderingManagement.Controller.AdminContoller;
import com.onlineFoodOrderingManagement.Controller.CustomerController;
import com.onlineFoodOrderingManagement.DataBase.DataBase;
import com.onlineFoodOrderingManagement.Service.AdminserviceImplement;

public class main {
	static AdminserviceImplement adser = new AdminserviceImplement();
	static AdminContoller adcon = new AdminContoller();
    static InputUtil in = new InputUtil();
    static DataBase db = new DataBase();
    static CustomerController cuscon = new CustomerController();
    
	public static void main(String[] args) {
		
		DataBase.catitem.size();
//		adser.CustomIteam();
		System.out.println("Welcome to Cholas hotel");
		while(true) {
		System.out.println("1.admin 2.customer");
		int choose = in.getint("enter your choice : ");
		
		switch(choose) {
		case 1 : 
			adcon.showAdmindashboard();
			break;
		case 2 :
		    cuscon.customerpage();
			break;
		}
		
		}
	}

}
