package com.onlineFoodOrderingManagement.InputUtil;

import java.util.Scanner;

public class InputUtil {
	
	Scanner s = new Scanner(System.in);
	
	public String getsrt(String msg) {
		System.out.println(msg);
		return s.next();
	}
	public int getint(String msg) {
		System.out.println(msg);
		while(!s.hasNextInt()) {
			System.out.println("invalid");
			s.next();
		}
			return s.nextInt();
	}

}
