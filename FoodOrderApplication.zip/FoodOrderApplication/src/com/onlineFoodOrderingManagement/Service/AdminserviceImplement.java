package com.onlineFoodOrderingManagement.Service;

import java.util.ArrayList;
import java.util.List;

import com.onlineFoodOrderingManagement.DataBase.DataBase;
import com.onlineFoodOrderingManagement.InputUtil.InputUtil;
import com.onlineFoodOrderingManagementEntity.FoodIteam;

public class AdminserviceImplement implements AdminService {
	
	static DataBase db = new DataBase();
	static InputUtil in = new InputUtil();
	
	public void addCategory(
			) {
		String cat = in.getsrt("enter the Category name : ");
		if(!DataBase.catitem.containsKey(cat)) {
			
			DataBase.catitem.put(cat, new ArrayList<>());
			System.out.println("New Category of " + " " + cat + " "+" has Added ");
		}else {
		System.out.println("your entered category is already exsit");
		}
	}
	
	public void removeCatagory() {
		String catagoryname = in.getsrt("enter the catagoryname");
		if(DataBase.catitem.containsKey(catagoryname)) {
			DataBase.catitem.remove(catagoryname);
			System.out.println(catagoryname +" "+"sucessfully removed ");
		}else {
		System.out.println("your metioned " + catagoryname +" "+ "is not there in list");
	}
	}
	
	@Override
	public void addIteam() {
		String categoryname = in.getsrt("Enter the categoryName :");
		if(DataBase.catitem.containsKey(categoryname)) {
			
			int id = in.getint("Enter the id :");
			String FoodName = in.getsrt("Enter the FoodName :");
			int Price = in.getint("enter the price");
			String catagory = in.getsrt("enter your categoryName : ");
			
			boolean alreadyexist = DataBase.catitem.get(categoryname).stream().anyMatch(item -> item.getFoodIid() == id || item.getFoodName().equalsIgnoreCase(categoryname) );
			
			if(alreadyexist) {	
                  System.out.println("your given id or foodname is already exit");			
            }else {	
				DataBase.catitem.get(categoryname).add(new FoodIteam(id , FoodName , Price , catagory));
}
		System.out.println("your given category list is added successfully");
		}else {
			System.out.println("your given Category is not exist check the correct one or create a new one...");
		}
		
	}

	@Override
	public void removeIteam() {
		String categoryname = in.getsrt("enter the categoryname");
		
		if(DataBase.catitem.containsKey(categoryname)) {
			String itemname = in.getsrt("enter the itemname :");
			
			boolean removed = DataBase.catitem.get(categoryname).removeIf(item -> item.getFoodName().equalsIgnoreCase(itemname));
			if(removed) {
			System.out.println("your requested "+" "+itemname+"sucessfully removed ");
		} else
			System.out.println("your req"+ categoryname +" "+"not in there list");
		}
		}

	@Override
	public void viewIteam() {
		for(String e : DataBase.catitem.keySet()) {
			System.out.println("----------------"+e+"------------------");
			
			List<FoodIteam> fooditem = DataBase.catitem.get(e);
			for(FoodIteam fi : fooditem) {
				System.out.println(fi.getFoodIid() +"    "
						+ fi.getFoodName() +"  -- "
						+ "₹"+fi.getPrice());
			}
			System.out.println();
		}
		
	}

}
