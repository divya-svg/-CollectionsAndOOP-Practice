package com.onlineFoodOrderingManagement.Service;

import java.util.ArrayList;
import java.util.List;

import com.onlineFoodOrderingManagement.DataBase.DataBase;
import com.onlineFoodOrderingManagement.InputUtil.InputUtil;
import com.onlineFoodOrderingManagementEntity.FoodIteam;

public class CustomerService {
	static DataBase db = new DataBase();
	static AdminserviceImplement adser = new AdminserviceImplement();
	static InputUtil in = new InputUtil();
	
	public void orderplaced() {

	    boolean order = true;
	    List<FoodIteam> cart = new ArrayList<>();
	    InputUtil in = new InputUtil();

	    while (order) {
	        boolean itemfound = false;

	        String catagoryName = in.getsrt("enter the catagory name :");

	        if (DataBase.catitem.containsKey(catagoryName)) {
	            int foodId = in.getint("enter the foodid :");

	            for (FoodIteam fi : DataBase.catitem.get(catagoryName)) {
	                if (fi.getFoodIid() == foodId) {
	                    cart.add(fi);
	                    System.out.println(fi.getFoodName() + " successfully added to your order.");
	                    itemfound = true;
	                    break;
	                }
	            }
	            if (!itemfound) {
	                System.out.println("Your mentioned foodId " + foodId + " is not found.");
	            }
	        } else {
	            System.out.println("Your given category " + catagoryName + " is not in the menu.");
	        }
	        
	        System.out.println("Do you want more 1.Yes 0.No.");
	        int choose = in.getint("Choose your choice : ");
	        if (choose == 0) {
	            order = false;
	        }
	    }
	    System.out.println("----------Your order summary-----------");
	    System.out.println("");
        int total=0;
	    for (FoodIteam e : cart) {
	        System.out.println(e.getFoodIid()+" "+
	        		e.getFoodName()+" "+" --₹"+
	        		e.getPrice());
	            total +=e.getPrice();
	        
	    }
	    System.out.println(" ");
	    System.out.println( "   "+"total amount to pay"+" "+ total+" ");
	    System.out.println(" ");
	    System.out.println("------------THANK YOU-----------");
	}
	

	}
