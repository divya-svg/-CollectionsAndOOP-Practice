package com.onlineFoodOrderingManagement.Service;

public interface AdminService {
	public void addIteam();
	public void removeIteam();
	public void viewIteam();
}
