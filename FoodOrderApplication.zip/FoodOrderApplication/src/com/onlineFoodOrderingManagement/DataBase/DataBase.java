package com.onlineFoodOrderingManagement.DataBase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.onlineFoodOrderingManagementEntity.FoodIteam;

public class DataBase {
        public static  Map<String, List<FoodIteam>> catitem = new HashMap<>();
        
        static {
            catitem.put("Starter", new ArrayList<>(Arrays.asList( 
                new FoodIteam(101, "Veg Spring Roll", 80, "Starter"),
                new FoodIteam(102, "Chicken 65", 150, "Starter"),
                new FoodIteam(103, "Paneer Tikka", 200, "Starter"),
                new FoodIteam(104, "Gobi Manchurian", 100, "Starter"),
                new FoodIteam(105, "Tomato Soup", 90, "Starter")
            )));

            catitem.put("MainCourse", new ArrayList<>(Arrays.asList(
                new FoodIteam(201,"Chicken Biryani", 250,"MainCourse"),
                new FoodIteam(202,"Veg Fried Rice", 200,"MainCourse"),
                new FoodIteam(203,"Paneer Butter Masala", 220,"MainCourse"),
                new FoodIteam(204,"Butter Naan", 40,"MainCourse"),
                new FoodIteam(205,"Mutton Curry", 280,"MainCourse")
            )));

            catitem.put("Dessert", new ArrayList<>(Arrays.asList(
                new FoodIteam(301,"Gulab Jamun", 60,"Dessert"),
                new FoodIteam(302,"Chocolate Brownie", 100,"Dessert"),
                new FoodIteam(303,"Rasgulla", 50,"Dessert"),
                new FoodIteam(304,"Ice Cream (Vanilla/Choco)", 80,"Dessert"),
                new FoodIteam(305,"Kheer", 90,"Dessert")
            )));

            catitem.put("Beverage", new ArrayList<>(Arrays.asList(
                new FoodIteam(401,"Lemon Juice", 30,"Beverage"),
                new FoodIteam(402,"Cold Coffee", 100,"Beverage"),
                new FoodIteam(403,"Masala Tea", 20,"Beverage"),
                new FoodIteam(404,"Mango Milkshake", 120,"Beverage"),
                new FoodIteam(405,"Coca-Cola", 50,"Beverage")
            )));
        }

}
