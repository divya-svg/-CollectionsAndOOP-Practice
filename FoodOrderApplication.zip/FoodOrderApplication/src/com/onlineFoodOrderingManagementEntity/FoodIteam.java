package com.onlineFoodOrderingManagementEntity;

public class FoodIteam {
	private int foodIid;
	private String foodName;
	private int Price;
	private String catagory;
	
	
	
	public FoodIteam(int foodIid, String foodName, int price, String catagory) {
		super();
		this.foodIid = foodIid;
		this.foodName = foodName;
		this.Price = price;
		this.catagory = catagory;
	}
	public int getFoodIid() {
		return foodIid;
	}
	public void setFoodIid(int foodIid) {
		this.foodIid = foodIid;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public String getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}
	@Override
	public String toString() {
		return "FoodIteam [foodIid=" + foodIid + ", foodName=" + foodName + ", Price=" + Price + ", catagory="
				+ catagory + "]";
	}
	
	

}
